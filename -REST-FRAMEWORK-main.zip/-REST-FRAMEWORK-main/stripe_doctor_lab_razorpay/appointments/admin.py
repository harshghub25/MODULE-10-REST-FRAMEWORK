from django.contrib import admin
from .models import Doctor, Appointment
admin.site.register(Doctor)
admin.site.register(Appointment)
